<?php
	include 'database.php';
    //$base_url = "http://localhost/shbs";
     $base_url = "http://localhost/shbs";
    

?>